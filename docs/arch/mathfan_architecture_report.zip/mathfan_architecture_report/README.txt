MathFan architecture report
Repo: colinzou-git/mathfan
Branch: main
Snapshot: 53cdf0f8653642ff04ac2b10e0380826ed347313
Open index.html first.
