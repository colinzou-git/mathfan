from pathlib import Path
from datetime import datetime

out = Path('/mnt/data/mathfan_architecture_report')
commit = '53cdf0f8653642ff04ac2b10e0380826ed347313'
source_date = '2026-06-09'

css = r'''
:root{
  --bg:#f7f8ff; --ink:#172033; --muted:#68738a; --card:#ffffff; --line:#dce3f5;
  --indigo:#4f46e5; --blue:#0284c7; --green:#16a34a; --yellow:#f59e0b; --red:#ef4444; --purple:#7c3aed; --pink:#db2777;
  --shadow:0 20px 45px rgba(35,45,80,.12); --radius:22px;
}
*{box-sizing:border-box} body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:radial-gradient(circle at top left,#e0f2fe 0,#eef2ff 25%,#fff 58%,#fef3c7 100%);color:var(--ink);line-height:1.55}
header.hero{padding:48px 24px 30px;background:linear-gradient(135deg,#312e81,#4f46e5 45%,#06b6d4);color:white;position:relative;overflow:hidden}
header.hero:after{content:"";position:absolute;right:-90px;top:-90px;width:280px;height:280px;border-radius:999px;background:rgba(255,255,255,.18)}
.wrap{max-width:1180px;margin:0 auto;padding:0 22px}.hero .wrap{position:relative;z-index:1}.eyebrow{letter-spacing:.14em;text-transform:uppercase;font-size:12px;font-weight:800;opacity:.9}.title{font-size:clamp(34px,6vw,70px);line-height:1.02;margin:10px 0 10px;font-weight:900}.subtitle{font-size:18px;max-width:860px;opacity:.94}.meta{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.pill{border-radius:999px;padding:7px 12px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.28);font-size:13px;font-weight:700}.nav{position:sticky;top:0;z-index:5;background:rgba(255,255,255,.88);backdrop-filter:blur(10px);border-bottom:1px solid #e5e7eb}.nav .wrap{display:flex;gap:8px;flex-wrap:wrap;padding-top:10px;padding-bottom:10px}.nav a{color:#334155;text-decoration:none;font-weight:800;font-size:14px;border:1px solid #e5e7eb;border-radius:999px;padding:8px 12px;background:white}.nav a.active,.nav a:hover{background:#4f46e5;color:white;border-color:#4f46e5}.section{padding:28px 0}.grid{display:grid;gap:18px}.grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}.grid.three{grid-template-columns:repeat(3,minmax(0,1fr))}.grid.four{grid-template-columns:repeat(4,minmax(0,1fr))}@media(max-width:850px){.grid.two,.grid.three,.grid.four{grid-template-columns:1fr}.hide-sm{display:none}}
.card{background:var(--card);border:1px solid #e7ecf8;border-radius:var(--radius);box-shadow:var(--shadow);padding:22px}.card h2,.card h3{margin-top:0}.small{font-size:13px;color:var(--muted)}.big-number{font-size:42px;font-weight:900;line-height:1;color:#4f46e5}.tag{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:5px 10px;font-size:12px;font-weight:800;background:#eef2ff;color:#3730a3}.tag.green{background:#dcfce7;color:#166534}.tag.yellow{background:#fef3c7;color:#92400e}.tag.red{background:#fee2e2;color:#991b1b}.tag.blue{background:#e0f2fe;color:#075985}.tag.purple{background:#ede9fe;color:#5b21b6}.tag.pink{background:#fce7f3;color:#9d174d}.legend{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.lead{font-size:18px;color:#334155}.note{border-left:5px solid #4f46e5;background:#eef2ff;padding:14px 16px;border-radius:14px}.warn{border-left:5px solid #f59e0b;background:#fffbeb;padding:14px 16px;border-radius:14px}.danger{border-left:5px solid #ef4444;background:#fef2f2;padding:14px 16px;border-radius:14px}.ok{border-left:5px solid #16a34a;background:#f0fdf4;padding:14px 16px;border-radius:14px}
table{border-collapse:separate;border-spacing:0;width:100%;font-size:14px;overflow:hidden;border-radius:16px;border:1px solid #e5e7eb;background:white}th{background:#111827;color:white;text-align:left}th,td{padding:12px;border-bottom:1px solid #eef2f7;vertical-align:top}tr:last-child td{border-bottom:0}td code,li code,p code{background:#f1f5f9;border:1px solid #e2e8f0;padding:1px 5px;border-radius:6px;color:#0f172a}.matrix td:nth-child(1){font-weight:800;color:#3730a3}.source{font-size:12px;color:#64748b;margin-top:8px}.diagram{width:100%;overflow:auto;background:#f8fafc;border:1px solid #e2e8f0;border-radius:18px;padding:12px}.flow{display:flex;gap:14px;align-items:stretch;flex-wrap:wrap}.node{min-width:145px;flex:1;background:white;border:2px solid #dbeafe;border-radius:16px;padding:13px;box-shadow:0 8px 18px rgba(15,23,42,.06)}.node .n-title{font-weight:900}.node .n-sub{font-size:12px;color:#64748b}.arrow{display:flex;align-items:center;justify-content:center;color:#64748b;font-weight:900;font-size:22px}.node.indigo{border-color:#818cf8;background:#eef2ff}.node.blue{border-color:#38bdf8;background:#e0f2fe}.node.green{border-color:#4ade80;background:#dcfce7}.node.yellow{border-color:#facc15;background:#fef9c3}.node.red{border-color:#f87171;background:#fee2e2}.node.purple{border-color:#a78bfa;background:#ede9fe}.node.pink{border-color:#f472b6;background:#fce7f3}.timeline{position:relative;padding-left:22px}.timeline:before{content:"";position:absolute;left:7px;top:0;bottom:0;width:3px;background:linear-gradient(#4f46e5,#06b6d4,#16a34a)}.step{position:relative;margin:0 0 16px;background:white;border:1px solid #e2e8f0;border-radius:16px;padding:14px}.step:before{content:"";position:absolute;left:-21px;top:17px;width:14px;height:14px;border-radius:999px;background:#4f46e5;border:3px solid white;box-shadow:0 0 0 2px #4f46e5}.footer{padding:24px;color:#64748b;font-size:12px;text-align:center}.svg-wrap{width:100%;overflow:auto}.callout-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}.mini-card{padding:14px;border:1px solid #e5e7eb;border-radius:16px;background:#fff}.mini-card b{display:block;margin-bottom:4px}.path{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono",monospace;font-size:12px;color:#334155;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;display:block;white-space:normal}.kbd{display:inline-block;font-family:ui-monospace,monospace;border:1px solid #cbd5e1;border-bottom-width:2px;border-radius:6px;padding:1px 6px;background:white;color:#334155}.heat{display:grid;grid-template-columns:repeat(7,1fr);gap:8px}.heat div{border-radius:12px;padding:12px;text-align:center;font-weight:900;color:white}.toc{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}.toc a{display:block;text-decoration:none;color:inherit;background:white;border:1px solid #e7ecf8;border-radius:18px;padding:18px;box-shadow:var(--shadow)}.toc a:hover{transform:translateY(-2px);transition:.15s}.toc span{display:block;font-size:12px;font-weight:800;color:#4f46e5;text-transform:uppercase;letter-spacing:.08em}.toc b{display:block;font-size:20px;margin:4px 0}.muted{color:var(--muted)}
'''

def nav(active):
    items=[('index.html','Overview'),('features.html','Features + tech map'),('data.html','Data + flows'),('decisions.html','Decisions + scale')]
    return '<nav class="nav"><div class="wrap">' + ''.join(f'<a class="{"active" if f==active else ""}" href="{f}">{label}</a>' for f,label in items) + '</div></nav>'

def hero(title, subtitle, active):
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>{css}</style></head><body>
<header class="hero"><div class="wrap"><div class="eyebrow">MathFan architecture report</div><h1 class="title">{title}</h1><p class="subtitle">{subtitle}</p><div class="meta"><span class="pill">Repo: colinzou-git/mathfan</span><span class="pill">Branch: main</span><span class="pill">Snapshot: {commit[:7]}</span><span class="pill">Generated: {source_date}</span></div></div></header>{nav(active)}'''

def footer():
    return f'''<div class="footer">Based on the main branch snapshot {commit[:12]}… and source files fetched during analysis. This is a static report; it does not modify the repository.</div></body></html>'''

index = hero('Current Architecture', 'A guided, visual map of the app structure, tech stack, module boundaries, and how data moves through MathFan.', 'index.html') + r'''
<main class="wrap">
<section class="section">
  <div class="toc">
    <a href="features.html"><span>Page 2</span><b>Feature map</b><p class="muted">Feature inventory, user flows, and mapping from features to code modules and libraries.</p></a>
    <a href="data.html"><span>Page 3</span><b>Data + flows</b><p class="muted">IndexedDB schema, canonical event log, FSRS scheduling, Google Drive sync, and answer lifecycle.</p></a>
    <a href="decisions.html"><span>Page 4</span><b>Design choices</b><p class="muted">Why the current choices make sense, where to be careful, and better options as MathFan grows.</p></a>
  </div>
</section>
<section class="section grid two">
  <div class="card">
    <h2>Executive summary</h2>
    <p class="lead">MathFan is a <b>local-first React/Vite/TypeScript PWA</b> for adaptive elementary math practice. The app stores student state in IndexedDB through Dexie, uses FSRS for spaced review, optionally syncs a snapshot to Google Drive appDataFolder, and offers optional Gemini-powered tutoring.</p>
    <div class="legend"><span class="tag green">Local-first</span><span class="tag blue">PWA</span><span class="tag purple">FSRS</span><span class="tag yellow">Event log</span><span class="tag pink">Optional AI</span></div>
    <p class="source">Main evidence: package.json, README, App.tsx, dexie.ts, scheduler.ts, fsrsAdapter.ts, snapshot.ts, driveSync.ts, gemini.ts.</p>
  </div>
  <div class="card">
    <h2>Architecture style</h2>
    <div class="callout-grid">
      <div class="mini-card"><b>Frontend shell</b><span class="path">src/App.tsx</span><p>App-level screen state chooses setup, dashboard, practice, stats, settings, quiz, mastery map, and diagnostic flows.</p></div>
      <div class="mini-card"><b>Domain features</b><span class="path">src/features/*</span><p>Practice, scheduler, curriculum, learning, mastery, diagnosis, sync, AI, audio, stats, dashboard.</p></div>
      <div class="mini-card"><b>Persistence</b><span class="path">src/db/*</span><p>Dexie tables and repository wrappers isolate IndexedDB access.</p></div>
      <div class="mini-card"><b>Generated learning items</b><span class="path">src/features/curriculum/*</span><p>Deterministic item IDs make sync, rebuild, stats, and focused practice possible.</p></div>
    </div>
  </div>
</section>
<section class="section">
  <div class="card">
    <h2>Big-picture architecture diagram</h2>
    <div class="svg-wrap">
    <svg width="1120" height="560" viewBox="0 0 1120 560" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="MathFan architecture diagram">
      <defs><filter id="shadow" x="-10%" y="-10%" width="120%" height="120%"><feDropShadow dx="0" dy="8" stdDeviation="8" flood-color="#0f172a" flood-opacity="0.15"/></filter><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#64748b"/></marker></defs>
      <rect x="10" y="10" width="1100" height="540" rx="26" fill="#f8fafc" stroke="#dbeafe"/>
      <rect x="60" y="70" width="230" height="120" rx="20" fill="#eef2ff" stroke="#6366f1" filter="url(#shadow)"/><text x="175" y="110" text-anchor="middle" font-size="20" font-weight="800" fill="#312e81">React App Shell</text><text x="175" y="137" text-anchor="middle" font-size="13" fill="#475569">App.tsx screen state</text><text x="175" y="160" text-anchor="middle" font-size="13" fill="#475569">Profile · Dashboard · Practice</text>
      <rect x="390" y="40" width="260" height="110" rx="20" fill="#e0f2fe" stroke="#0284c7" filter="url(#shadow)"/><text x="520" y="82" text-anchor="middle" font-size="19" font-weight="800" fill="#075985">Practice Engine</text><text x="520" y="108" text-anchor="middle" font-size="13" fill="#475569">usePracticeSession</text><text x="520" y="130" text-anchor="middle" font-size="13" fill="#475569">answer checking + session queue</text>
      <rect x="390" y="200" width="260" height="110" rx="20" fill="#dcfce7" stroke="#16a34a" filter="url(#shadow)"/><text x="520" y="242" text-anchor="middle" font-size="19" font-weight="800" fill="#14532d">Scheduler + FSRS</text><text x="520" y="268" text-anchor="middle" font-size="13" fill="#475569">scheduler.ts</text><text x="520" y="290" text-anchor="middle" font-size="13" fill="#475569">fsrsAdapter.ts</text>
      <rect x="390" y="360" width="260" height="110" rx="20" fill="#fef3c7" stroke="#f59e0b" filter="url(#shadow)"/><text x="520" y="402" text-anchor="middle" font-size="19" font-weight="800" fill="#92400e">Curriculum Items</text><text x="520" y="428" text-anchor="middle" font-size="13" fill="#475569">deterministic IDs</text><text x="520" y="450" text-anchor="middle" font-size="13" fill="#475569">makeItemFromId()</text>
      <rect x="760" y="70" width="260" height="130" rx="20" fill="#ede9fe" stroke="#7c3aed" filter="url(#shadow)"/><text x="890" y="112" text-anchor="middle" font-size="19" font-weight="800" fill="#5b21b6">IndexedDB / Dexie</text><text x="890" y="138" text-anchor="middle" font-size="13" fill="#475569">students · sessions</text><text x="890" y="160" text-anchor="middle" font-size="13" fill="#475569">itemStates · attempts</text><text x="890" y="182" text-anchor="middle" font-size="13" fill="#475569">mathAnswerEvents</text>
      <rect x="760" y="250" width="260" height="110" rx="20" fill="#fce7f3" stroke="#db2777" filter="url(#shadow)"/><text x="890" y="292" text-anchor="middle" font-size="19" font-weight="800" fill="#9d174d">Optional Integrations</text><text x="890" y="318" text-anchor="middle" font-size="13" fill="#475569">Google Drive sync</text><text x="890" y="340" text-anchor="middle" font-size="13" fill="#475569">Gemini tutor · Web Speech</text>
      <rect x="760" y="410" width="260" height="80" rx="20" fill="#fee2e2" stroke="#ef4444" filter="url(#shadow)"/><text x="890" y="445" text-anchor="middle" font-size="18" font-weight="800" fill="#991b1b">CI/CD + PWA</text><text x="890" y="470" text-anchor="middle" font-size="13" fill="#475569">Vite · Workbox · Pages</text>
      <line x1="290" y1="130" x2="390" y2="95" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="520" y1="150" x2="520" y2="200" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="520" y1="310" x2="520" y2="360" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="650" y1="95" x2="760" y2="125" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="650" y1="255" x2="760" y2="135" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="650" y1="415" x2="760" y2="145" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="890" y1="200" x2="890" y2="250" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/><line x1="890" y1="360" x2="890" y2="410" stroke="#64748b" stroke-width="3" marker-end="url(#arrow)"/>
      <text x="175" y="210" text-anchor="middle" font-size="12" fill="#64748b">UI routes are screen-state driven, not URL-route driven.</text>
    </svg>
    </div>
  </div>
</section>
<section class="section grid three">
  <div class="card"><div class="big-number">7</div><h3>Top-level app screens</h3><p>Setup, dashboard, daily/range setup, practice, stats, settings, quiz, today detail, mastery map, diagnostic. Some are subflows rather than URL routes.</p></div>
  <div class="card"><div class="big-number">7</div><h3>Grade 3 mastery domains</h3><p>Add/subtract, multiplication, division, fractions, area/perimeter, geometry, measurement/data.</p></div>
  <div class="card"><div class="big-number">8</div><h3>IndexedDB tables</h3><p>Students, item states, attempts, sessions, multiplication fact stats, quiz sessions, canonical answer events, plus Dexie schema versions.</p></div>
</section>
<section class="section">
  <div class="card">
    <h2>Repository areas at a glance</h2>
    <table>
      <thead><tr><th>Area</th><th>Role</th><th>Important files</th></tr></thead>
      <tbody>
        <tr><td>App shell</td><td>Loads auth/voices, chooses current screen, coordinates profile and sync side effects.</td><td><code>src/App.tsx</code>, <code>src/main.tsx</code></td></tr>
        <tr><td>Practice</td><td>Runs practice sessions, keyboard/numpad input, hints, AI tutor overlay, audio, visual feedback.</td><td><code>src/features/practice/PracticeScreen.tsx</code>, <code>usePracticeSession.ts</code>, <code>answerChecker.ts</code></td></tr>
        <tr><td>Curriculum</td><td>Generates practice items and reconstructs them from stable IDs for sync/rebuild.</td><td><code>src/features/curriculum/*</code>, <code>makeItemFromId.ts</code></td></tr>
        <tr><td>Scheduling</td><td>Adaptive daily review and per-item FSRS scheduling.</td><td><code>scheduler.ts</code>, <code>fsrsAdapter.ts</code></td></tr>
        <tr><td>Learning events</td><td>Canonical answer event log and derived-cache repair after sync.</td><td><code>learningEvents.ts</code>, <code>recordAnswer.ts</code>, <code>eventRebuild.ts</code></td></tr>
        <tr><td>Mastery map</td><td>Grade 3 skills, summaries, today's plan, skill detail and parent next-action UI.</td><td><code>grade3MasteryMap.ts</code>, <code>skillMasteryEngine.ts</code>, <code>todayPlanEngine.ts</code></td></tr>
        <tr><td>Sync/auth</td><td>Google GIS sign-in and Drive appDataFolder JSON snapshot sync.</td><td><code>googleAuth.ts</code>, <code>useSync.ts</code>, <code>driveSync.ts</code>, <code>snapshot.ts</code></td></tr>
        <tr><td>Platform</td><td>PWA manifest, Workbox service worker, GitHub Pages deploy, tests and lint.</td><td><code>vite.config.ts</code>, <code>.github/workflows/deploy.yml</code>, <code>package.json</code></td></tr>
      </tbody>
    </table>
  </div>
</section>
</main>
''' + footer()

features = hero('Features + Tech Mapping', 'A feature-by-feature view of what MathFan does, where it lives in code, and which third-party or browser APIs support each feature.', 'features.html') + r'''
<main class="wrap">
<section class="section grid two">
  <div class="card">
    <h2>Feature groups</h2>
    <div class="heat">
      <div style="background:#4f46e5">Practice</div><div style="background:#0284c7">Curriculum</div><div style="background:#16a34a">FSRS</div><div style="background:#f59e0b">Stats</div><div style="background:#7c3aed">Mastery Map</div><div style="background:#db2777">Sync</div><div style="background:#ef4444">AI + Audio</div>
    </div>
    <p class="small">The app is feature-folder driven. A feature usually owns its UI, model logic, tests, and helper functions.</p>
  </div>
  <div class="card">
    <h2>Core student journey</h2>
    <div class="flow"><div class="node indigo"><div class="n-title">Create profile</div><div class="n-sub">name + grade</div></div><div class="arrow">→</div><div class="node blue"><div class="n-title">Choose practice</div><div class="n-sub">range / daily / map / quiz</div></div><div class="arrow">→</div><div class="node green"><div class="n-title">Answer</div><div class="n-sub">numpad / keyboard / choice</div></div><div class="arrow">→</div><div class="node yellow"><div class="n-title">Persist + schedule</div><div class="n-sub">event log + FSRS</div></div></div>
  </div>
</section>
<section class="section">
  <div class="card">
    <h2>Feature → code → stack matrix</h2>
    <table class="matrix">
      <thead><tr><th>Feature</th><th>Main code</th><th>Tech/API used</th><th>Notes</th></tr></thead>
      <tbody>
        <tr><td>Profile setup/settings</td><td><code>ProfileSetup.tsx</code>, <code>SettingsPage.tsx</code>, <code>StudentProfile</code></td><td>React state, Dexie, localStorage for selected integrations</td><td>DB supports multiple profiles, but current startup selects the first profile unless sync refresh selects the event-rich profile.</td></tr>
        <tr><td>Operation/range setup</td><td><code>RangeSetup.tsx</code>, <code>SessionSetup.tsx</code>, <code>opSpecs.ts</code></td><td>React UI + typed <code>SessionConfig</code></td><td>Unified range setup supports multiplication/division/addition/subtraction/fractions and one-range operations.</td></tr>
        <tr><td>Practice session</td><td><code>PracticeScreen.tsx</code>, <code>usePracticeSession.ts</code>, <code>answerChecker.ts</code></td><td>React hooks, Dexie transactions, Web Speech API, optional Gemini overlay</td><td>First attempt updates FSRS; retries are logged but do not update long-term schedule.</td></tr>
        <tr><td>Adaptive review</td><td><code>scheduler.ts</code>, <code>fsrsAdapter.ts</code></td><td><code>ts-fsrs</code></td><td>Planner uses due / weak / new split; FSRS adapter is the only direct import of <code>ts-fsrs</code>.</td></tr>
        <tr><td>Curriculum generation</td><td><code>curriculum/*Items.ts</code>, <code>makeItemFromId.ts</code></td><td>TypeScript deterministic factories, <code>fraction.js</code> for misconception checks</td><td>Stable item IDs are essential for sync, history, stats, mastery, and reconstructing generated items.</td></tr>
        <tr><td>Visual models</td><td><code>features/visuals/*</code></td><td>React SVG/CSS, <code>mafs</code>, <code>@dnd-kit</code></td><td>Array models, fraction bars, number lines, clocks, shape/area models, draggable equal groups.</td></tr>
        <tr><td>Grade 3 mastery map</td><td><code>grade3MasteryMap.ts</code>, <code>Grade3MasteryMapPage.tsx</code>, <code>skillMasteryEngine.ts</code></td><td>Derived event/state summaries</td><td>Prerequisites are a soft advisory/ranking signal, not a hard lock.</td></tr>
        <tr><td>Quick Check diagnostic</td><td><code>DiagnosticSession.tsx</code>, <code>diagnosticPlanner.ts</code>, <code>diagnosticPersistence.ts</code></td><td>QuestionRenderer, NumPad, Dexie, FSRS</td><td>Diagnostic answers are recorded into the same canonical event log and update item state through the same write path.</td></tr>
        <tr><td>Stats/history/growth</td><td><code>features/stats/*</code>, <code>repositories.ts</code></td><td>Dexie date-range queries, React tables/charts</td><td>Stats should increasingly read from <code>mathAnswerEvents</code>; attempts remain a compatibility layer.</td></tr>
        <tr><td>Google sync</td><td><code>googleAuth.ts</code>, <code>useSync.ts</code>, <code>driveSync.ts</code>, <code>snapshot.ts</code></td><td>Google Identity Services, Drive API appDataFolder</td><td>Snapshot merge unions canonical events and rebuilds derived caches after merge.</td></tr>
        <tr><td>AI tutor</td><td><code>TutorChat.tsx</code>, <code>gemini.ts</code>, <code>aiConfig.ts</code></td><td>Gemini REST API, localStorage API key</td><td>Prompt rules instruct the tutor to guide without revealing final answers. Key is not included in Drive snapshot.</td></tr>
        <tr><td>Audio</td><td><code>speech.ts</code>, <code>mathSpeech.ts</code></td><td>Web Speech API</td><td>Math-aware speech normalizes symbols and fractions before TTS.</td></tr>
        <tr><td>PWA/deployment</td><td><code>vite.config.ts</code>, <code>main.tsx</code>, <code>deploy.yml</code></td><td>Vite, vite-plugin-pwa, Workbox, GitHub Actions/Pages</td><td>Service worker uses skipWaiting/clientsClaim and app reloads on controllerchange when an update activates.</td></tr>
      </tbody>
    </table>
  </div>
</section>
<section class="section grid two">
  <div class="card"><h2>Practice flow</h2><div class="timeline">
    <div class="step"><b>1. App chooses practice screen</b><p><code>App.tsx</code> saves return destination and sends <code>SessionConfig</code> to <code>PracticeScreen</code>.</p></div>
    <div class="step"><b>2. Session queue is built</b><p><code>usePracticeSession</code> generates dynamic items or selects specific/daily-review items.</p></div>
    <div class="step"><b>3. Student answers</b><p><code>answerChecker</code> validates input and maps correctness/latency to <code>again/hard/good/easy</code>.</p></div>
    <div class="step"><b>4. First attempt schedules</b><p><code>applyReview</code> calls the FSRS adapter for durable item state and next due date.</p></div>
    <div class="step"><b>5. Event is written</b><p><code>recordPracticeAnswer</code> stores answer event, item state, and compatibility attempt log in one Dexie transaction.</p></div>
    <div class="step"><b>6. UI advances</b><p>Auto-advance waits for correct-answer speech to finish, preventing the next question from cutting off the answer audio.</p></div>
  </div></div>
  <div class="card"><h2>Mastery-map flow</h2><div class="timeline">
    <div class="step"><b>1. Load events + states</b><p>Map page loads <code>mathAnswerEvents</code> and <code>itemStates</code>.</p></div>
    <div class="step"><b>2. Reconstruct item metadata</b><p><code>makeItemFromId</code> resolves dynamic IDs into typed items.</p></div>
    <div class="step"><b>3. Infer skill IDs</b><p><code>skillMapping</code> maps item types/tags to Grade 3 skill nodes.</p></div>
    <div class="step"><b>4. Derive summaries</b><p><code>skillMasteryEngine</code> calculates attempts, accuracy, due count, status, and misconception tags.</p></div>
    <div class="step"><b>5. Plan today</b><p><code>todayPlanEngine</code> picks warmup, focus, review, and prerequisite advisory.</p></div>
  </div></div>
</section>
<section class="section">
  <div class="card">
    <h2>Third-party dependencies and why they are present</h2>
    <table>
      <thead><tr><th>Library</th><th>Used for</th><th>Why it fits</th><th>Watch-outs</th></tr></thead>
      <tbody>
        <tr><td><code>react</code>/<code>react-dom</code></td><td>All UI rendering</td><td>Strong fit for mobile PWA screens and component reuse.</td><td>Current app uses manual screen state instead of URL routes; future deep links may need router adoption.</td></tr>
        <tr><td><code>vite</code> + <code>@vitejs/plugin-react</code></td><td>Dev/build pipeline</td><td>Fast, simple static build for GitHub Pages/PWA.</td><td>Base path must be correct for project pages vs custom domain.</td></tr>
        <tr><td><code>vite-plugin-pwa</code></td><td>Manifest and service worker generation</td><td>Minimal PWA setup without custom service-worker complexity.</td><td>SW updates can confuse testing; version/build info helps confirm live bundle.</td></tr>
        <tr><td><code>dexie</code></td><td>IndexedDB tables and transactions</td><td>Local-first storage with structured queries and schema versions.</td><td>Schema migration discipline matters as student data grows.</td></tr>
        <tr><td><code>ts-fsrs</code></td><td>Official FSRS scheduling</td><td>Avoids maintaining custom spaced-repetition math.</td><td>Keep isolated in adapter so API changes affect one file.</td></tr>
        <tr><td><code>mafs</code></td><td>Math visualizations such as fraction number lines</td><td>Cleaner than hand-rolled coordinate math for graph-like visuals.</td><td>Check mobile performance and bundle weight as visual count grows.</td></tr>
        <tr><td><code>@dnd-kit/*</code></td><td>Drag/drop visual models</td><td>Modern accessible drag/drop for equal-group interactions.</td><td>Touch behavior on iPad must be device-tested.</td></tr>
        <tr><td><code>fraction.js</code></td><td>Fraction misconception/normalization logic</td><td>Reduces edge-case risk in fraction comparison/simplification.</td><td>Prefer centralized usage; avoid mixed custom fraction logic.</td></tr>
        <tr><td><code>vitest</code> + Testing Library</td><td>Unit/component tests</td><td>Matches Vite stack and supports JS DOM component tests.</td><td>Regression tests should cover every scheduling/sync/audio bug fix.</td></tr>
      </tbody>
    </table>
  </div>
</section>
</main>
''' + footer()

data = hero('Data Model + Runtime Flows', 'The important part of MathFan is not only the UI: it is how answers become durable learning history, schedules, mastery summaries, stats, and syncable state.', 'data.html') + r'''
<main class="wrap">
<section class="section grid two">
  <div class="card">
    <h2>Data philosophy</h2>
    <p class="lead">The architecture is moving toward <b>event-sourced learning data</b>: <code>mathAnswerEvents</code> is the canonical record, while <code>itemStates</code>, <code>attempts</code>, <code>multFactStats</code>, and <code>quizSessions</code> are caches or compatibility views.</p>
    <div class="ok"><b>Good design choice:</b> after sync, derived tables are rebuilt from the union of events, reducing stale aggregate conflicts across devices.</div>
  </div>
  <div class="card">
    <h2>Tables</h2>
    <table>
      <thead><tr><th>Table</th><th>Purpose</th><th>Truth level</th></tr></thead>
      <tbody>
        <tr><td><code>students</code></td><td>Profile, grade, timezone, settings</td><td>Primary</td></tr>
        <tr><td><code>mathAnswerEvents</code></td><td>Every quiz/practice/diagnostic answer</td><td><b>Canonical</b></td></tr>
        <tr><td><code>itemStates</code></td><td>FSRS/card state, mastery level, due date, mistake patterns</td><td>Derived cache</td></tr>
        <tr><td><code>attempts</code></td><td>Legacy per-answer compatibility log</td><td>Compatibility</td></tr>
        <tr><td><code>sessions</code></td><td>Practice session summaries</td><td>Primary summary</td></tr>
        <tr><td><code>multFactStats</code></td><td>Quiz fact mastery cache</td><td>Derived cache</td></tr>
        <tr><td><code>quizSessions</code></td><td>Completed quiz summaries</td><td>Derived/summary</td></tr>
      </tbody>
    </table>
  </div>
</section>
<section class="section">
  <div class="card">
    <h2>Answer write pipeline</h2>
    <div class="diagram"><div class="flow"><div class="node blue"><div class="n-title">Student input</div><div class="n-sub">keyboard · NumPad · choice</div></div><div class="arrow">→</div><div class="node indigo"><div class="n-title">checkAnswer()</div><div class="n-sub">strict parse + latency grade</div></div><div class="arrow">→</div><div class="node green"><div class="n-title">applyReview()</div><div class="n-sub">first attempt only</div></div><div class="arrow">→</div><div class="node purple"><div class="n-title">recordPracticeAnswer()</div><div class="n-sub">Dexie transaction</div></div><div class="arrow">→</div><div class="node yellow"><div class="n-title">UI feedback</div><div class="n-sub">hint · speech · next</div></div></div></div>
    <div class="grid three" style="margin-top:18px">
      <div class="mini-card"><b>Wrong answer</b><p>Stored as <code>reviewGrade='again'</code>; retry stays on same question. First wrong attempt can add misconception tags.</p></div>
      <div class="mini-card"><b>Slow correct</b><p>Correct answers can become <code>hard</code>, not <code>again</code>, so they do not become false FSRS failures.</p></div>
      <div class="mini-card"><b>Retry</b><p>Retry events are saved for stats/history but do not update <code>itemStates</code> or FSRS.</p></div>
    </div>
  </div>
</section>
<section class="section grid two">
  <div class="card">
    <h2>FSRS state</h2>
    <table>
      <thead><tr><th>Field</th><th>Meaning</th></tr></thead>
      <tbody>
        <tr><td><code>stabilityDays</code></td><td>How long memory is expected to last, in days.</td></tr>
        <tr><td><code>fsrsDifficulty</code></td><td>Per-card difficulty from the FSRS model.</td></tr>
        <tr><td><code>reps</code>, <code>lapses</code></td><td>Review and lapse counters.</td></tr>
        <tr><td><code>lastSeenAt</code>, <code>nextDueAt</code></td><td>Last review and next scheduled review time.</td></tr>
        <tr><td><code>fsrsCardState</code>, <code>fsrsScheduledDays</code>, <code>fsrsLearningSteps</code></td><td>Stored to reconstruct a <code>ts-fsrs</code> card later.</td></tr>
      </tbody>
    </table>
    <p class="small">The adapter disables short-term learning steps and fuzz for deterministic behavior and predictable tests.</p>
  </div>
  <div class="card">
    <h2>Mastery status layers</h2>
    <div class="flow"><div class="node yellow"><div class="n-title">Item state</div><div class="n-sub">new → learning → developing → strong → mastered</div></div><div class="arrow">→</div><div class="node purple"><div class="n-title">Skill summary</div><div class="n-sub">new / needs practice / review due / strong / mastered</div></div></div>
    <p>Item mastery comes from accuracy and FSRS stability. Skill mastery comes from first-attempt events, due item counts, number of distinct items, and thresholds.</p>
    <div class="warn"><b>Important:</b> A skill should not be marked mastered from repeated drilling of a single item. The skill engine requires multiple distinct items for mastery.</div>
  </div>
</section>
<section class="section">
  <div class="card">
    <h2>Sync architecture</h2>
    <div class="svg-wrap"><svg width="1050" height="360" viewBox="0 0 1050 360" xmlns="http://www.w3.org/2000/svg"><defs><marker id="ar2" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#64748b"/></marker></defs><rect x="20" y="40" width="210" height="110" rx="18" fill="#eef2ff" stroke="#4f46e5"/><text x="125" y="82" text-anchor="middle" font-size="18" font-weight="800">Local IndexedDB</text><text x="125" y="112" text-anchor="middle" font-size="13">Dexie tables</text><rect x="320" y="40" width="210" height="110" rx="18" fill="#e0f2fe" stroke="#0284c7"/><text x="425" y="82" text-anchor="middle" font-size="18" font-weight="800">Snapshot JSON</text><text x="425" y="112" text-anchor="middle" font-size="13">buildSnapshot()</text><rect x="620" y="40" width="210" height="110" rx="18" fill="#fce7f3" stroke="#db2777"/><text x="725" y="82" text-anchor="middle" font-size="18" font-weight="800">Google Drive</text><text x="725" y="112" text-anchor="middle" font-size="13">appDataFolder</text><rect x="320" y="220" width="210" height="100" rx="18" fill="#dcfce7" stroke="#16a34a"/><text x="425" y="260" text-anchor="middle" font-size="18" font-weight="800">Merge</text><text x="425" y="288" text-anchor="middle" font-size="13">union events by id</text><rect x="620" y="220" width="260" height="100" rx="18" fill="#fef3c7" stroke="#f59e0b"/><text x="750" y="260" text-anchor="middle" font-size="18" font-weight="800">Rebuild derived caches</text><text x="750" y="288" text-anchor="middle" font-size="13">itemStates + multFactStats</text><line x1="230" y1="95" x2="320" y2="95" stroke="#64748b" stroke-width="3" marker-end="url(#ar2)"/><line x1="530" y1="95" x2="620" y2="95" stroke="#64748b" stroke-width="3" marker-end="url(#ar2)"/><line x1="725" y1="150" x2="500" y2="220" stroke="#64748b" stroke-width="3" marker-end="url(#ar2)"/><line x1="530" y1="270" x2="620" y2="270" stroke="#64748b" stroke-width="3" marker-end="url(#ar2)"/><line x1="620" y1="302" x2="230" y2="132" stroke="#64748b" stroke-width="3" marker-end="url(#ar2)"/><text x="425" y="180" font-size="13" text-anchor="middle" fill="#64748b">syncBothWays(): pull/merge first, then push local</text></svg></div>
    <div class="grid three" style="margin-top:18px"><div class="mini-card"><b>Auth</b><p>Google Identity Services token client is preloaded; tokens stay in memory only.</p></div><div class="mini-card"><b>Storage</b><p>Drive file name is <code>mathfan-data.json</code> in the private appDataFolder.</p></div><div class="mini-card"><b>Conflict model</b><p>Events are merged by ID; derived tables are recomputed after merge.</p></div></div>
  </div>
</section>
<section class="section grid two">
  <div class="card"><h2>PWA update flow</h2><p>Vite PWA is configured with Workbox precaching, <code>skipWaiting</code>, and <code>clientsClaim</code>. <code>main.tsx</code> listens for <code>controllerchange</code> and reloads after a new service worker activates, except on the first install.</p><div class="note"><b>Take care:</b> when debugging “old UI” issues, verify service worker state, app build version, base path, and cache update behavior.</div></div>
  <div class="card"><h2>AI/audio state</h2><p>AI key and model live in localStorage, not the profile or sync snapshot. Audio uses browser speech synthesis and normalizes math expressions before speaking.</p><div class="danger"><b>Take care:</b> localStorage API keys are convenient but not high-security. A sign-in-gated serverless proxy is a better public-scale option.</div></div>
</section>
</main>
''' + footer()

decisions = hero('Design Decisions, Risks, and Scaling Options', 'Why the current architecture was chosen, what to protect during future code changes, and where the design can improve as MathFan grows.', 'decisions.html') + r'''
<main class="wrap">
<section class="section grid two">
  <div class="card"><h2>Why the current design is reasonable</h2><table><thead><tr><th>Choice</th><th>Reason</th></tr></thead><tbody>
    <tr><td>Local-first PWA</td><td>Best fit for a child-facing practice app: no backend required, works offline, fast, private by default, installable on iPad/phone/desktop.</td></tr>
    <tr><td>Dexie/IndexedDB</td><td>Structured local storage with transactions, indexes, and schema migration support.</td></tr>
    <tr><td>Event log as source of truth</td><td>Allows rebuilding derived mastery/scheduler caches and makes cross-device sync safer.</td></tr>
    <tr><td>FSRS via adapter</td><td>Good separation: app logic uses MathFan review grades; only one file knows the third-party FSRS API.</td></tr>
    <tr><td>Deterministic item IDs</td><td>Critical for generated questions. Same ID can be reconstructed after reload/sync without storing every generated item forever.</td></tr>
    <tr><td>Drive appDataFolder sync</td><td>Lower operational burden than running a server; data stays in the user’s Google account.</td></tr>
    <tr><td>Optional Gemini tutor</td><td>Preserves core offline/local practice while giving families an opt-in hint system.</td></tr>
  </tbody></table></div>
  <div class="card"><h2>Current tradeoffs</h2><table><thead><tr><th>Tradeoff</th><th>Impact</th></tr></thead><tbody>
    <tr><td>Manual screen state instead of URL routing</td><td>Simpler for a small app, but harder to deep-link, restore exact sub-screen state, or use browser back/forward.</td></tr>
    <tr><td>Inline styles in many components</td><td>Fast iteration, but harder to enforce theme consistency and responsive design at scale.</td></tr>
    <tr><td>Snapshot sync instead of row-level backend sync</td><td>Simple and private, but larger snapshots and coarser conflict handling as data grows.</td></tr>
    <tr><td>API key in localStorage</td><td>Convenient for personal/family use, but not ideal for public app security.</td></tr>
    <tr><td>Multiple profiles partially implemented</td><td>DB supports it, but startup/profile switching UX needs a real chooser.</td></tr>
  </tbody></table></div>
</section>
<section class="section">
  <div class="card"><h2>Things to take care of during future changes</h2><div class="callout-grid">
    <div class="mini-card"><span class="tag red">Do not break</span><b>Canonical event log</b><p>New stats/mastery should prefer <code>mathAnswerEvents</code>. Keep attempts as compatibility unless intentionally migrating.</p></div>
    <div class="mini-card"><span class="tag red">Do not break</span><b>First-attempt scheduling</b><p>Retries must stay logged but must not update FSRS item state.</p></div>
    <div class="mini-card"><span class="tag yellow">Be careful</span><b>Generated item IDs</b><p>Every generated item type needs a stable ID and a matching <code>makeItemFromId</code> parser.</p></div>
    <div class="mini-card"><span class="tag yellow">Be careful</span><b>Sync merge</b><p>After merging remote snapshot, derived caches must be rebuilt from merged events.</p></div>
    <div class="mini-card"><span class="tag yellow">Be careful</span><b>Google sign-in timing</b><p>GIS token requests are sensitive to user gestures, popups, local origins, and COOP behavior.</p></div>
    <div class="mini-card"><span class="tag blue">Test</span><b>Speech auto-advance</b><p>Advance only after answer speech finishes, or the next prompt may cut off feedback audio.</p></div>
    <div class="mini-card"><span class="tag blue">Test</span><b>Service worker caching</b><p>When UI looks stale, test with version/commit display, fresh query params, and SW unregister/reload.</p></div>
    <div class="mini-card"><span class="tag purple">Architecture rule</span><b>FSRS import boundary</b><p>Keep <code>ts-fsrs</code> isolated in <code>fsrsAdapter.ts</code>; callers should use <code>applyReview</code>/<code>applyFsrsReview</code>.</p></div>
  </div></div>
</section>
<section class="section grid two">
  <div class="card"><h2>Scalability assessment</h2><table><thead><tr><th>Dimension</th><th>Current state</th><th>Scaling concern</th></tr></thead><tbody>
    <tr><td>More grades/skills</td><td>Feature folders and deterministic item factories scale reasonably.</td><td>Skill mapping may become brittle if rules remain hard-coded; consider data-driven curriculum definitions.</td></tr>
    <tr><td>More students/devices</td><td>IndexedDB + Drive snapshot works for family use.</td><td>Large snapshots and merge time can grow; row-level sync or chunked event sync may be needed.</td></tr>
    <tr><td>More visuals</td><td>VisualModel abstraction supports adding types.</td><td>Bundle size and mobile performance need monitoring; lazy-load heavy visuals if needed.</td></tr>
    <tr><td>More AI use</td><td>Optional BYO Gemini key is simple.</td><td>Public deployment needs server-side key protection, abuse control, and safety logging/privacy review.</td></tr>
    <tr><td>More analytics</td><td>Event log supports recomputation.</td><td>IndexedDB queries over many events may need indexes, materialized summaries, or paginated processing.</td></tr>
    <tr><td>Classroom use</td><td>Current design is family/local-first.</td><td>Needs account model, roster, admin dashboard, consent/privacy workflows, and backend sync.</td></tr>
  </tbody></table></div>
  <div class="card"><h2>Better design options by stage</h2><div class="timeline">
    <div class="step"><b>Near-term: keep local-first</b><p>Add profile picker, export/import JSON, stronger version/build display, more regression tests, and data repair tools using event rebuild.</p></div>
    <div class="step"><b>Medium-term: data-driven curriculum</b><p>Move skill metadata, prerequisite advisory, item generators, and mappings into declarative configs with validation tests.</p></div>
    <div class="step"><b>Medium-term: router adoption</b><p>Use React Router for shareable URLs and back-button behavior while keeping the app shell simple.</p></div>
    <div class="step"><b>Public-scale: backend sync</b><p>Move from Drive snapshots to Firestore/Supabase/custom backend if classroom/large multi-device sync becomes a goal.</p></div>
    <div class="step"><b>Public-scale: AI proxy</b><p>Replace local API keys with a sign-in-gated serverless proxy, rate limits, and model policy controls.</p></div>
  </div></div>
</section>
<section class="section">
  <div class="card"><h2>Recommended architecture guardrails</h2><table><thead><tr><th>Guardrail</th><th>Implementation idea</th><th>Why</th></tr></thead><tbody>
    <tr><td>All generated items must round-trip</td><td>Test every item factory ID with <code>makeItemFromId(id)</code>.</td><td>Prevents sync/rebuild failures and missing mastery-map items.</td></tr>
    <tr><td>One answer write path</td><td>Practice/diagnostic should use <code>recordPracticeAnswer</code> or a wrapper.</td><td>Keeps event log, item state, and attempts consistent.</td></tr>
    <tr><td>Derived cache rebuild tests</td><td>Given event fixtures, rebuild itemStates/multFactStats and compare expected state.</td><td>Protects sync and data repair.</td></tr>
    <tr><td>Service worker visibility</td><td>Show version, git SHA, build time, and update status in Settings.</td><td>Makes deployment/cache bugs obvious.</td></tr>
    <tr><td>Mobile acceptance tests</td><td>Manual iPad checklist plus Playwright viewport tests.</td><td>MathFan’s primary device is mobile/tablet.</td></tr>
    <tr><td>AI never reveals answer</td><td>Prompt tests/red-team cases around “tell me the answer.”</td><td>Preserves tutor purpose and child learning value.</td></tr>
  </tbody></table></div>
</section>
<section class="section grid two">
  <div class="card"><h2>Suggested folder evolution</h2><pre class="path">src/
  app/                 # App shell, navigation, route/screen orchestration
  db/                  # Dexie schema + repos + migrations
  features/
    practice/
    curriculum/
    scheduler/
    mastery/
    diagnosis/
    stats/
    sync/
    ai/
    audio/
  shared/
    components/
    utils/
    theme/
  tests/</pre><p class="small">This is close to the current structure. Main change: gradually move generic shared UI/utils out of domain feature folders when they are reused.</p></div>
  <div class="card"><h2>Priority improvements</h2><ol>
    <li><b>Profile picker:</b> DB supports multiple profiles, but startup selection and “switch student” need a real choose-existing flow.</li>
    <li><b>Export/import:</b> Use the existing snapshot format as the starting point, but add validation and “new learning track” semantics.</li>
    <li><b>Curriculum config:</b> Centralize skill mapping and item generation coverage tests.</li>
    <li><b>Sync/privacy:</b> Add optional encryption or at least clear warnings for Drive snapshots.</li>
    <li><b>Router:</b> Adopt URL routes if deep links/history become important.</li>
  </ol></div>
</section>
</main>
''' + footer()

files = {
    'index.html': index,
    'features.html': features,
    'data.html': data,
    'decisions.html': decisions,
}
for name, content in files.items():
    (out/name).write_text(content, encoding='utf-8')

# Add a README for the artifact bundle
(out/'README.txt').write_text(f"MathFan architecture report\nRepo: colinzou-git/mathfan\nBranch: main\nSnapshot: {commit}\nOpen index.html first.\n", encoding='utf-8')
